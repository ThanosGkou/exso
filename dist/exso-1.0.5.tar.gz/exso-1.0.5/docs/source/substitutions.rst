.. |xlsm| image:: figs/exso_xlsm_logo.png
.. |logo| image:: figs/logos/geodetic.png